using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace SimatSoft.FixAsset
{
    public partial class Form_003001_REPORT : Form
    {
        public Form_003001_REPORT()
        {
            InitializeComponent();
        }

        private void Form_003001_REPORT_Load(object sender, EventArgs e)
        {
        }
    }
}