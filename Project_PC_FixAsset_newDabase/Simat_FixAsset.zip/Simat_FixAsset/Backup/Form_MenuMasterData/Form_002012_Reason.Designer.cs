namespace SimatSoft.FixAsset
{
    partial class Form_002012_Reason
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel2 = new System.Windows.Forms.Panel();
            this.sS_DataGridView_Reason = new SimatSoft.CustomControl.SS_DataGridView();
            this.panel_Reason = new System.Windows.Forms.Panel();
            this.sS_MaskedTextBox_Reason = new SimatSoft.CustomControl.SS_MaskedTextBox();
            this.LBL_Reason = new System.Windows.Forms.Label();
            this.LBL_ReasonNo = new System.Windows.Forms.Label();
            this.sS_MaskedTextBox_ReasonNo = new SimatSoft.CustomControl.SS_MaskedTextBox();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel_Record = new System.Windows.Forms.ToolStripStatusLabel();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sS_DataGridView_Reason)).BeginInit();
            this.panel_Reason.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel2.Controls.Add(this.sS_DataGridView_Reason);
            this.panel2.Location = new System.Drawing.Point(4, 116);
            this.panel2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(581, 361);
            this.panel2.TabIndex = 5;
            // 
            // sS_DataGridView_Reason
            // 
            this.sS_DataGridView_Reason.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.sS_DataGridView_Reason.BackColorCellFocus = System.Drawing.Color.LightBlue;
            this.sS_DataGridView_Reason.BackColorCellLeave = System.Drawing.Color.Honeydew;
            this.sS_DataGridView_Reason.BackColorRow = System.Drawing.Color.HotPink;
            this.sS_DataGridView_Reason.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.sS_DataGridView_Reason.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.sS_DataGridView_Reason.Dock = System.Windows.Forms.DockStyle.Fill;
            this.sS_DataGridView_Reason.Location = new System.Drawing.Point(0, 0);
            this.sS_DataGridView_Reason.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.sS_DataGridView_Reason.Name = "sS_DataGridView_Reason";
            this.sS_DataGridView_Reason.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.sS_DataGridView_Reason.Size = new System.Drawing.Size(577, 357);
            this.sS_DataGridView_Reason.TabIndex = 0;
            this.sS_DataGridView_Reason.Click += new System.EventHandler(this.sS_DataGridView_Reason_Click);
            // 
            // panel_Reason
            // 
            this.panel_Reason.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.panel_Reason.BackColor = System.Drawing.Color.Transparent;
            this.panel_Reason.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel_Reason.Controls.Add(this.sS_MaskedTextBox_Reason);
            this.panel_Reason.Controls.Add(this.LBL_Reason);
            this.panel_Reason.Controls.Add(this.LBL_ReasonNo);
            this.panel_Reason.Controls.Add(this.sS_MaskedTextBox_ReasonNo);
            this.panel_Reason.Location = new System.Drawing.Point(1, 4);
            this.panel_Reason.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel_Reason.Name = "panel_Reason";
            this.panel_Reason.Size = new System.Drawing.Size(584, 104);
            this.panel_Reason.TabIndex = 4;
            // 
            // sS_MaskedTextBox_Reason
            // 
            this.sS_MaskedTextBox_Reason.BackColor = System.Drawing.Color.Lavender;
            this.sS_MaskedTextBox_Reason.BackColorOnFocus = System.Drawing.Color.LightBlue;
            this.sS_MaskedTextBox_Reason.BackColorOnLeave = System.Drawing.Color.Lavender;
            this.sS_MaskedTextBox_Reason.BoolChangeFontOnFocus = true;
            this.sS_MaskedTextBox_Reason.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.sS_MaskedTextBox_Reason.FontLostFocus = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.sS_MaskedTextBox_Reason.FontOnFocus = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.sS_MaskedTextBox_Reason.IconError = null;
            this.sS_MaskedTextBox_Reason.IconTrue = null;
            this.sS_MaskedTextBox_Reason.Location = new System.Drawing.Point(153, 54);
            this.sS_MaskedTextBox_Reason.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.sS_MaskedTextBox_Reason.Masked = SimatSoft.CustomControl.Mask.None;
            this.sS_MaskedTextBox_Reason.Name = "sS_MaskedTextBox_Reason";
            this.sS_MaskedTextBox_Reason.Size = new System.Drawing.Size(404, 26);
            this.sS_MaskedTextBox_Reason.TabIndex = 2;
            // 
            // LBL_Reason
            // 
            this.LBL_Reason.AutoSize = true;
            this.LBL_Reason.Location = new System.Drawing.Point(44, 63);
            this.LBL_Reason.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LBL_Reason.Name = "LBL_Reason";
            this.LBL_Reason.Size = new System.Drawing.Size(61, 17);
            this.LBL_Reason.TabIndex = 2;
            this.LBL_Reason.Text = "Reason:";
            // 
            // LBL_ReasonNo
            // 
            this.LBL_ReasonNo.AutoSize = true;
            this.LBL_ReasonNo.Location = new System.Drawing.Point(44, 31);
            this.LBL_ReasonNo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LBL_ReasonNo.Name = "LBL_ReasonNo";
            this.LBL_ReasonNo.Size = new System.Drawing.Size(83, 17);
            this.LBL_ReasonNo.TabIndex = 2;
            this.LBL_ReasonNo.Text = "Reason No:";
            // 
            // sS_MaskedTextBox_ReasonNo
            // 
            this.sS_MaskedTextBox_ReasonNo.BackColor = System.Drawing.Color.Honeydew;
            this.sS_MaskedTextBox_ReasonNo.BackColorOnFocus = System.Drawing.Color.LightBlue;
            this.sS_MaskedTextBox_ReasonNo.BackColorOnLeave = System.Drawing.Color.Honeydew;
            this.sS_MaskedTextBox_ReasonNo.BoolChangeFontOnFocus = true;
            this.sS_MaskedTextBox_ReasonNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.sS_MaskedTextBox_ReasonNo.FontLostFocus = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.sS_MaskedTextBox_ReasonNo.FontOnFocus = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.sS_MaskedTextBox_ReasonNo.IconError = null;
            this.sS_MaskedTextBox_ReasonNo.IconTrue = null;
            this.sS_MaskedTextBox_ReasonNo.Location = new System.Drawing.Point(153, 22);
            this.sS_MaskedTextBox_ReasonNo.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.sS_MaskedTextBox_ReasonNo.Masked = SimatSoft.CustomControl.Mask.None;
            this.sS_MaskedTextBox_ReasonNo.Name = "sS_MaskedTextBox_ReasonNo";
            this.sS_MaskedTextBox_ReasonNo.Size = new System.Drawing.Size(199, 26);
            this.sS_MaskedTextBox_ReasonNo.TabIndex = 1;
            this.sS_MaskedTextBox_ReasonNo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.sS_MaskedTextBox_ReasonNo_KeyPress);
            // 
            // statusStrip1
            // 
            this.statusStrip1.BackColor = System.Drawing.SystemColors.Control;
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel_Record});
            this.statusStrip1.Location = new System.Drawing.Point(0, 481);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Padding = new System.Windows.Forms.Padding(1, 0, 19, 0);
            this.statusStrip1.Size = new System.Drawing.Size(589, 27);
            this.statusStrip1.TabIndex = 11;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel_Record
            // 
            this.toolStripStatusLabel_Record.BorderSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.Right;
            this.toolStripStatusLabel_Record.Name = "toolStripStatusLabel_Record";
            this.toolStripStatusLabel_Record.Size = new System.Drawing.Size(104, 22);
            this.toolStripStatusLabel_Record.Text = "[1/All] records";
            // 
            // Form_002012_Reason
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.ClientSize = new System.Drawing.Size(589, 508);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel_Reason);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Form_002012_Reason";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ID:002012(Reason)";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form_002012_Reason_FormClosed);
            this.Activated += new System.EventHandler(this.Form_002012_Reason_Activated);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form_002012_Reason_FormClosing);
            this.Load += new System.EventHandler(this.Form_002012_Reason_Load);
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.sS_DataGridView_Reason)).EndInit();
            this.panel_Reason.ResumeLayout(false);
            this.panel_Reason.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel2;
        private SimatSoft.CustomControl.SS_DataGridView sS_DataGridView_Reason;
        private System.Windows.Forms.Panel panel_Reason;
        private SimatSoft.CustomControl.SS_MaskedTextBox sS_MaskedTextBox_Reason;
        private System.Windows.Forms.Label LBL_Reason;
        private System.Windows.Forms.Label LBL_ReasonNo;
        private SimatSoft.CustomControl.SS_MaskedTextBox sS_MaskedTextBox_ReasonNo;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel_Record;
    }
}