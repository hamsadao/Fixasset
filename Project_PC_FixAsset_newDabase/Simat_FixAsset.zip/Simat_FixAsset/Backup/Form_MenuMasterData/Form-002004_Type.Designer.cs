namespace SimatSoft.FixAsset
{
    partial class Form_002004_Type
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel_Type = new System.Windows.Forms.Panel();
            this.sS_MaskedTextBox_TypeName = new SimatSoft.CustomControl.SS_MaskedTextBox();
            this.sS_MaskedTextBox_Remark = new SimatSoft.CustomControl.SS_MaskedTextBox();
            this.sS_MaskedTextBox_TypeNo = new SimatSoft.CustomControl.SS_MaskedTextBox();
            this.LBL_Remark = new System.Windows.Forms.Label();
            this.LBL_TypeName = new System.Windows.Forms.Label();
            this.LBL_TypeNo = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.sS_DataGridView_Type = new SimatSoft.CustomControl.SS_DataGridView();
            this.panel_Type.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sS_DataGridView_Type)).BeginInit();
            this.SuspendLayout();
            // 
            // panel_Type
            // 
            this.panel_Type.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.panel_Type.BackColor = System.Drawing.Color.Transparent;
            this.panel_Type.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel_Type.Controls.Add(this.sS_MaskedTextBox_TypeName);
            this.panel_Type.Controls.Add(this.sS_MaskedTextBox_Remark);
            this.panel_Type.Controls.Add(this.sS_MaskedTextBox_TypeNo);
            this.panel_Type.Controls.Add(this.LBL_Remark);
            this.panel_Type.Controls.Add(this.LBL_TypeName);
            this.panel_Type.Controls.Add(this.LBL_TypeNo);
            this.panel_Type.Location = new System.Drawing.Point(1, 2);
            this.panel_Type.Margin = new System.Windows.Forms.Padding(4);
            this.panel_Type.Name = "panel_Type";
            this.panel_Type.Size = new System.Drawing.Size(585, 133);
            this.panel_Type.TabIndex = 6;
            // 
            // sS_MaskedTextBox_TypeName
            // 
            this.sS_MaskedTextBox_TypeName.BackColor = System.Drawing.Color.Lavender;
            this.sS_MaskedTextBox_TypeName.BackColorOnFocus = System.Drawing.Color.LightBlue;
            this.sS_MaskedTextBox_TypeName.BackColorOnLeave = System.Drawing.Color.Lavender;
            this.sS_MaskedTextBox_TypeName.BoolChangeFontOnFocus = true;
            this.sS_MaskedTextBox_TypeName.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.sS_MaskedTextBox_TypeName.FontLostFocus = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.sS_MaskedTextBox_TypeName.FontOnFocus = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.sS_MaskedTextBox_TypeName.IconError = null;
            this.sS_MaskedTextBox_TypeName.IconTrue = null;
            this.sS_MaskedTextBox_TypeName.Location = new System.Drawing.Point(97, 47);
            this.sS_MaskedTextBox_TypeName.Margin = new System.Windows.Forms.Padding(4);
            this.sS_MaskedTextBox_TypeName.Masked = SimatSoft.CustomControl.Mask.None;
            this.sS_MaskedTextBox_TypeName.Name = "sS_MaskedTextBox_TypeName";
            this.sS_MaskedTextBox_TypeName.Size = new System.Drawing.Size(481, 26);
            this.sS_MaskedTextBox_TypeName.TabIndex = 2;
            this.sS_MaskedTextBox_TypeName.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.sS_MaskedTextBox_TypeName_KeyPress);
            // 
            // sS_MaskedTextBox_Remark
            // 
            this.sS_MaskedTextBox_Remark.BackColor = System.Drawing.Color.Lavender;
            this.sS_MaskedTextBox_Remark.BackColorOnFocus = System.Drawing.Color.LightBlue;
            this.sS_MaskedTextBox_Remark.BackColorOnLeave = System.Drawing.Color.Lavender;
            this.sS_MaskedTextBox_Remark.BoolChangeFontOnFocus = true;
            this.sS_MaskedTextBox_Remark.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.sS_MaskedTextBox_Remark.FontLostFocus = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.sS_MaskedTextBox_Remark.FontOnFocus = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.sS_MaskedTextBox_Remark.IconError = null;
            this.sS_MaskedTextBox_Remark.IconTrue = null;
            this.sS_MaskedTextBox_Remark.Location = new System.Drawing.Point(97, 79);
            this.sS_MaskedTextBox_Remark.Margin = new System.Windows.Forms.Padding(4);
            this.sS_MaskedTextBox_Remark.Masked = SimatSoft.CustomControl.Mask.None;
            this.sS_MaskedTextBox_Remark.Multiline = true;
            this.sS_MaskedTextBox_Remark.Name = "sS_MaskedTextBox_Remark";
            this.sS_MaskedTextBox_Remark.Size = new System.Drawing.Size(481, 40);
            this.sS_MaskedTextBox_Remark.TabIndex = 3;
            // 
            // sS_MaskedTextBox_TypeNo
            // 
            this.sS_MaskedTextBox_TypeNo.BackColor = System.Drawing.Color.Honeydew;
            this.sS_MaskedTextBox_TypeNo.BackColorOnFocus = System.Drawing.Color.LightBlue;
            this.sS_MaskedTextBox_TypeNo.BackColorOnLeave = System.Drawing.Color.Honeydew;
            this.sS_MaskedTextBox_TypeNo.BoolChangeFontOnFocus = true;
            this.sS_MaskedTextBox_TypeNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.sS_MaskedTextBox_TypeNo.FontLostFocus = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.sS_MaskedTextBox_TypeNo.FontOnFocus = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.sS_MaskedTextBox_TypeNo.IconError = null;
            this.sS_MaskedTextBox_TypeNo.IconTrue = null;
            this.sS_MaskedTextBox_TypeNo.Location = new System.Drawing.Point(97, 15);
            this.sS_MaskedTextBox_TypeNo.Margin = new System.Windows.Forms.Padding(4);
            this.sS_MaskedTextBox_TypeNo.Masked = SimatSoft.CustomControl.Mask.None;
            this.sS_MaskedTextBox_TypeNo.Name = "sS_MaskedTextBox_TypeNo";
            this.sS_MaskedTextBox_TypeNo.Size = new System.Drawing.Size(157, 26);
            this.sS_MaskedTextBox_TypeNo.TabIndex = 1;
            this.sS_MaskedTextBox_TypeNo.DoubleClick += new System.EventHandler(this.sS_MaskedTextBox_TypeNo_DoubleClick);
            this.sS_MaskedTextBox_TypeNo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.sS_MaskedTextBox_TypeNo_KeyPress);
            // 
            // LBL_Remark
            // 
            this.LBL_Remark.AutoSize = true;
            this.LBL_Remark.Location = new System.Drawing.Point(8, 85);
            this.LBL_Remark.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LBL_Remark.Name = "LBL_Remark";
            this.LBL_Remark.Size = new System.Drawing.Size(61, 17);
            this.LBL_Remark.TabIndex = 2;
            this.LBL_Remark.Text = "Remark:";
            // 
            // LBL_TypeName
            // 
            this.LBL_TypeName.AutoSize = true;
            this.LBL_TypeName.Location = new System.Drawing.Point(8, 55);
            this.LBL_TypeName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LBL_TypeName.Name = "LBL_TypeName";
            this.LBL_TypeName.Size = new System.Drawing.Size(85, 17);
            this.LBL_TypeName.TabIndex = 2;
            this.LBL_TypeName.Text = "Type Name:";
            // 
            // LBL_TypeNo
            // 
            this.LBL_TypeNo.AutoSize = true;
            this.LBL_TypeNo.Location = new System.Drawing.Point(4, 21);
            this.LBL_TypeNo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LBL_TypeNo.Name = "LBL_TypeNo";
            this.LBL_TypeNo.Size = new System.Drawing.Size(70, 17);
            this.LBL_TypeNo.TabIndex = 2;
            this.LBL_TypeNo.Text = " Type No:";
            // 
            // panel2
            // 
            this.panel2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.panel2.Controls.Add(this.sS_DataGridView_Type);
            this.panel2.Location = new System.Drawing.Point(1, 144);
            this.panel2.Margin = new System.Windows.Forms.Padding(4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(587, 366);
            this.panel2.TabIndex = 7;
            // 
            // sS_DataGridView_Type
            // 
            this.sS_DataGridView_Type.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.sS_DataGridView_Type.BackColorCellFocus = System.Drawing.Color.LightBlue;
            this.sS_DataGridView_Type.BackColorCellLeave = System.Drawing.Color.Honeydew;
            this.sS_DataGridView_Type.BackColorRow = System.Drawing.Color.HotPink;
            this.sS_DataGridView_Type.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.sS_DataGridView_Type.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.sS_DataGridView_Type.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.sS_DataGridView_Type.DefaultCellStyle = dataGridViewCellStyle2;
            this.sS_DataGridView_Type.Dock = System.Windows.Forms.DockStyle.Fill;
            this.sS_DataGridView_Type.Location = new System.Drawing.Point(0, 0);
            this.sS_DataGridView_Type.Margin = new System.Windows.Forms.Padding(4);
            this.sS_DataGridView_Type.Name = "sS_DataGridView_Type";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.sS_DataGridView_Type.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.sS_DataGridView_Type.RowTemplate.Height = 24;
            this.sS_DataGridView_Type.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.sS_DataGridView_Type.Size = new System.Drawing.Size(587, 366);
            this.sS_DataGridView_Type.TabIndex = 0;
            this.sS_DataGridView_Type.Click += new System.EventHandler(this.sS_DataGridView_Type_Click);
            // 
            // Form_002004_Type
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(188)))), ((int)(((byte)(210)))), ((int)(((byte)(238)))));
            this.ClientSize = new System.Drawing.Size(593, 511);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel_Type);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form_002004_Type";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ID:002004(Type)";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form_002004_Type_FormClosed);
            this.Activated += new System.EventHandler(this.Form_002004_Type_Activated);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form_002004_Type_FormClosing);
            this.Load += new System.EventHandler(this.Form_002004_Type_Load);
            this.panel_Type.ResumeLayout(false);
            this.panel_Type.PerformLayout();
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.sS_DataGridView_Type)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel_Type;
        private SimatSoft.CustomControl.SS_MaskedTextBox sS_MaskedTextBox_Remark;
        private SimatSoft.CustomControl.SS_MaskedTextBox sS_MaskedTextBox_TypeNo;
        private System.Windows.Forms.Label LBL_Remark;
        private System.Windows.Forms.Label LBL_TypeName;
        private System.Windows.Forms.Label LBL_TypeNo;
        private SimatSoft.CustomControl.SS_MaskedTextBox sS_MaskedTextBox_TypeName;
        private System.Windows.Forms.Panel panel2;
        private SimatSoft.CustomControl.SS_DataGridView sS_DataGridView_Type;
    }
}