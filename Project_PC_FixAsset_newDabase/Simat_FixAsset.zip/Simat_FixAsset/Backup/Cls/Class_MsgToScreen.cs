using System;
using System.Collections.Generic;
using System.Text;

namespace SimatSoft.FixAsset
{
    class Class_MsgToScreen
    {
        public static string FN_SetID(object IdForm, object IdControl)
        {
            return "";
        }
    }
}
