namespace SimatSoft.FixAsset
{
    partial class Form_005007_Barcode_Custodian
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel2 = new System.Windows.Forms.Panel();
            this.label_Remark = new System.Windows.Forms.Label();
            this.sS_DataGridView_BarcodeCustodian = new SimatSoft.CustomControl.SS_DataGridView();
            this.sS_MaskedTextBox_Remark = new SimatSoft.CustomControl.SS_MaskedTextBox();
            this.sS_MaskedTextBox_CustodianID = new SimatSoft.CustomControl.SS_MaskedTextBox();
            this.label_CustodianID = new System.Windows.Forms.Label();
            this.sS_MaskedTextBox_CustodianName = new SimatSoft.CustomControl.SS_MaskedTextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.sS_ButtonGlass1 = new SimatSoft.CustomControl.SS_ButtonGlass();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sS_DataGridView_BarcodeCustodian)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.label_Remark);
            this.panel2.Controls.Add(this.sS_DataGridView_BarcodeCustodian);
            this.panel2.Controls.Add(this.sS_MaskedTextBox_Remark);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(0, 88);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(451, 0);
            this.panel2.TabIndex = 1;
            // 
            // label_Remark
            // 
            this.label_Remark.AutoSize = true;
            this.label_Remark.Location = new System.Drawing.Point(18, 17);
            this.label_Remark.Name = "label_Remark";
            this.label_Remark.Size = new System.Drawing.Size(47, 13);
            this.label_Remark.TabIndex = 11;
            this.label_Remark.Text = "Remark:";
            // 
            // sS_DataGridView_BarcodeCustodian
            // 
            this.sS_DataGridView_BarcodeCustodian.AllowUserToAddRows = false;
            this.sS_DataGridView_BarcodeCustodian.BackColorCellFocus = System.Drawing.Color.LightBlue;
            this.sS_DataGridView_BarcodeCustodian.BackColorCellLeave = System.Drawing.Color.Honeydew;
            this.sS_DataGridView_BarcodeCustodian.BackColorRow = System.Drawing.Color.HotPink;
            this.sS_DataGridView_BarcodeCustodian.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.sS_DataGridView_BarcodeCustodian.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.sS_DataGridView_BarcodeCustodian.Dock = System.Windows.Forms.DockStyle.Fill;
            this.sS_DataGridView_BarcodeCustodian.Location = new System.Drawing.Point(0, 0);
            this.sS_DataGridView_BarcodeCustodian.Name = "sS_DataGridView_BarcodeCustodian";
            this.sS_DataGridView_BarcodeCustodian.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.sS_DataGridView_BarcodeCustodian.Size = new System.Drawing.Size(451, 0);
            this.sS_DataGridView_BarcodeCustodian.TabIndex = 0;
            this.sS_DataGridView_BarcodeCustodian.Visible = false;
            this.sS_DataGridView_BarcodeCustodian.Click += new System.EventHandler(this.sS_DataGridView_BarcodeCustodian_Click);
            // 
            // sS_MaskedTextBox_Remark
            // 
            this.sS_MaskedTextBox_Remark.BackColor = System.Drawing.Color.Lavender;
            this.sS_MaskedTextBox_Remark.BackColorOnFocus = System.Drawing.Color.LightBlue;
            this.sS_MaskedTextBox_Remark.BackColorOnLeave = System.Drawing.Color.Lavender;
            this.sS_MaskedTextBox_Remark.BoolChangeFontOnFocus = true;
            this.sS_MaskedTextBox_Remark.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.sS_MaskedTextBox_Remark.FontLostFocus = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.sS_MaskedTextBox_Remark.FontOnFocus = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.sS_MaskedTextBox_Remark.IconError = null;
            this.sS_MaskedTextBox_Remark.IconTrue = null;
            this.sS_MaskedTextBox_Remark.Location = new System.Drawing.Point(113, 47);
            this.sS_MaskedTextBox_Remark.Masked = SimatSoft.CustomControl.Mask.None;
            this.sS_MaskedTextBox_Remark.Name = "sS_MaskedTextBox_Remark";
            this.sS_MaskedTextBox_Remark.Size = new System.Drawing.Size(312, 23);
            this.sS_MaskedTextBox_Remark.TabIndex = 10;
            // 
            // sS_MaskedTextBox_CustodianID
            // 
            this.sS_MaskedTextBox_CustodianID.BackColor = System.Drawing.Color.Honeydew;
            this.sS_MaskedTextBox_CustodianID.BackColorOnFocus = System.Drawing.Color.LightBlue;
            this.sS_MaskedTextBox_CustodianID.BackColorOnLeave = System.Drawing.Color.Honeydew;
            this.sS_MaskedTextBox_CustodianID.BoolChangeFontOnFocus = true;
            this.sS_MaskedTextBox_CustodianID.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.sS_MaskedTextBox_CustodianID.FontLostFocus = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.sS_MaskedTextBox_CustodianID.FontOnFocus = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.sS_MaskedTextBox_CustodianID.IconError = null;
            this.sS_MaskedTextBox_CustodianID.IconTrue = null;
            this.sS_MaskedTextBox_CustodianID.Location = new System.Drawing.Point(111, 20);
            this.sS_MaskedTextBox_CustodianID.Masked = SimatSoft.CustomControl.Mask.None;
            this.sS_MaskedTextBox_CustodianID.Name = "sS_MaskedTextBox_CustodianID";
            this.sS_MaskedTextBox_CustodianID.ReadOnly = true;
            this.sS_MaskedTextBox_CustodianID.Size = new System.Drawing.Size(233, 23);
            this.sS_MaskedTextBox_CustodianID.TabIndex = 7;
            this.sS_MaskedTextBox_CustodianID.KeyDown += new System.Windows.Forms.KeyEventHandler(this.sS_MaskedTextBox_AssetID_KeyDown);
            // 
            // label_CustodianID
            // 
            this.label_CustodianID.AutoSize = true;
            this.label_CustodianID.Location = new System.Drawing.Point(16, 30);
            this.label_CustodianID.Name = "label_CustodianID";
            this.label_CustodianID.Size = new System.Drawing.Size(77, 13);
            this.label_CustodianID.TabIndex = 9;
            this.label_CustodianID.Text = "Custodian No.:";
            // 
            // sS_MaskedTextBox_CustodianName
            // 
            this.sS_MaskedTextBox_CustodianName.BackColor = System.Drawing.Color.LightCyan;
            this.sS_MaskedTextBox_CustodianName.BackColorOnFocus = System.Drawing.Color.LightBlue;
            this.sS_MaskedTextBox_CustodianName.BackColorOnLeave = System.Drawing.Color.Honeydew;
            this.sS_MaskedTextBox_CustodianName.BoolChangeFontOnFocus = true;
            this.sS_MaskedTextBox_CustodianName.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.sS_MaskedTextBox_CustodianName.FontLostFocus = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.sS_MaskedTextBox_CustodianName.FontOnFocus = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.sS_MaskedTextBox_CustodianName.IconError = null;
            this.sS_MaskedTextBox_CustodianName.IconTrue = null;
            this.sS_MaskedTextBox_CustodianName.Location = new System.Drawing.Point(111, 51);
            this.sS_MaskedTextBox_CustodianName.Masked = SimatSoft.CustomControl.Mask.None;
            this.sS_MaskedTextBox_CustodianName.Name = "sS_MaskedTextBox_CustodianName";
            this.sS_MaskedTextBox_CustodianName.ReadOnly = true;
            this.sS_MaskedTextBox_CustodianName.Size = new System.Drawing.Size(334, 23);
            this.sS_MaskedTextBox_CustodianName.TabIndex = 8;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Transparent;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.sS_ButtonGlass1);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.sS_MaskedTextBox_CustodianName);
            this.panel1.Controls.Add(this.label_CustodianID);
            this.panel1.Controls.Add(this.sS_MaskedTextBox_CustodianID);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(451, 88);
            this.panel1.TabIndex = 0;
            // 
            // sS_ButtonGlass1
            // 
            this.sS_ButtonGlass1.Location = new System.Drawing.Point(350, 20);
            this.sS_ButtonGlass1.Name = "sS_ButtonGlass1";
            this.sS_ButtonGlass1.Size = new System.Drawing.Size(94, 23);
            this.sS_ButtonGlass1.TabIndex = 47;
            this.sS_ButtonGlass1.Text = "Print Barcode";
            this.sS_ButtonGlass1.Click += new System.EventHandler(this.sS_ButtonGlass1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(16, 56);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(88, 13);
            this.label1.TabIndex = 10;
            this.label1.Text = "Custodian Name:";
            // 
            // Form_005007_Barcode_Custodian
            // 
            this.ClientSize = new System.Drawing.Size(451, 88);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "Form_005007_Barcode_Custodian";
            this.Text = "ID:005007(Barcode Custodian)";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form_005001_Barcode_Asset_FormClosed);
            this.Activated += new System.EventHandler(this.Form_005001_Barcode_Asset_Activated);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form_005007_Barcode_Custodian_FormClosing);
            this.Load += new System.EventHandler(this.Form_005001_Barcode_Asset_Load);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sS_DataGridView_BarcodeCustodian)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel2;
        private SimatSoft.CustomControl.SS_MaskedTextBox sS_MaskedTextBox_CustodianID;
        private System.Windows.Forms.Label label_CustodianID;
        private SimatSoft.CustomControl.SS_MaskedTextBox sS_MaskedTextBox_CustodianName;
        private System.Windows.Forms.Panel panel1;
        private SimatSoft.CustomControl.SS_MaskedTextBox sS_MaskedTextBox_Remark;
        private System.Windows.Forms.Label label_Remark;
        private SimatSoft.CustomControl.SS_DataGridView sS_DataGridView_BarcodeCustodian;
        private System.Windows.Forms.Label label1;
        private SimatSoft.CustomControl.SS_ButtonGlass sS_ButtonGlass1;

    }
}