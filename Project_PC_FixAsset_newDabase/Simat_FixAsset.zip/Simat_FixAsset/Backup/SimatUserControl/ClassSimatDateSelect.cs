using System;
using System.Collections.Generic;
using System.Text;

namespace System.Windows.Forms.Samples
{
    class ClassSimatDateSelect:Simat_DataSelect 
    {
        public Data.DataRow dataconfig =null;
    }
}
