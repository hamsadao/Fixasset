using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace SimatSoft.FixAsset
{
    public partial class Form_001000_UserManul : Form
    {
        public Form_001000_UserManul()
        {
            InitializeComponent();
        }

        
    }
}